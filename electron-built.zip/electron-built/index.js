const {app, BrowserWindow, ipcMain } = require("electron"); 
// var xl = require("excel4node"); // for *creating* excel docs via the openXML specification/format. very fast.
var winax = require('winax') // for instantiation of COM/OLE/ActiveX objects or whatever they are.

function createWindow() {
  // Create the browser window.
  win = new BrowserWindow( {
    width:800, 
    height:600
  }); 

  // and load the index.html of the app.
  win.loadFile("index.html"); 
}

// load up main window when ready
app.on("ready", createWindow); 

// syncronous icp message response
ipcMain.on('make-workbook', (event, arg) =>  {
  makeWorkbook()
  event.returnValue = 'make-workbook succeeded!'
})

function makeWorkbook() {
  let xl = new winax.Object('Excel.Application'); // nearly identical to CreateObject() in vb. Exposes same API of the underlying object.
  xl.Visible = true

  // add a workbook and input data
  let wb = xl.Workbooks.Add();
  wb.sheets(1).range("A1").Value = "heck yea"
}
